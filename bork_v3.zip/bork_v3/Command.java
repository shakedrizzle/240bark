
package zeitz_borkv3;

abstract class Command {

    abstract String execute();

}
